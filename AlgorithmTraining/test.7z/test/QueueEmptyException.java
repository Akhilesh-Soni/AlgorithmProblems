package test;

public class QueueEmptyException extends Exception {

}
