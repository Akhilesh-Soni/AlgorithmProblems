package assignments;

public class QueueEmptyException extends Exception {

}
