package assignments;

public class BSTEmptyException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BSTEmptyException() {
		// TODO Auto-generated constructor stub
		super("BST is empty");
	}
}
