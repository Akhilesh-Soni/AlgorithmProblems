package flightplanner;

public class VertexNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VertexNotFoundException() {
		// TODO Auto-generated constructor stub
		super("No Vertex Found...");
	}
}
